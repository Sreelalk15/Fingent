

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Fingent Interview - Mark List</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('marks.create')); ?>">Create</a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered table-responsive-lg">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Maths</th>
            <th>Science</th>
            <th>History</th>
            <th>Term</th>
            <th>Total Marks</th>
            <th>Created On</th>
            <th>Actions</th>
        </tr>
         <?php $__currentLoopData = $data['marks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

            <tr> 
                <td><?php echo e($mark['id']); ?></td> 
                <td><?php echo e($mark['name']); ?></td> 
                <td><?php echo e($mark['maths']); ?></td>
                <td><?php echo e($mark['science']); ?></td>
                <td><?php echo e($mark['history']); ?></td>
                <td><?php echo e($mark['term']); ?></td>  
                <td><?php echo e($mark['maths'] + $mark['science'] + $mark['history']); ?></td>
                <td>
                    <?php echo e(date('F d, Y', strtotime($mark['created_at']))); ?><br>
                    <?php echo e(date('h:i A', strtotime($mark['created_at']))); ?>

                </td>
                <td> 
                    <form action="<?php echo e(route('marks.destroy',$mark['id'])); ?>" method="POST">
                        <?php echo csrf_field(); ?>     
                        <a href="<?php echo e(route('marks.edit',$mark['id'])); ?>">Edit</a>&nbsp;&nbsp;/&nbsp;&nbsp;    
                        <?php echo method_field('DELETE'); ?>       
                        <button type="submit">Delete</button> 
                    </form> 
                </td> 
            </tr> 
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\fingent-interview\resources\views/mark/index.blade.php ENDPATH**/ ?>