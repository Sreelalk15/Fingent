<html>

<head>
    <title>Fingent Interview - <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
    
    </script>

    <style>
        .footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            background-color: #9C27B0;
            color: white;
            text-align: center;
        }

    </style>

</head>

<body>
    <?php $__env->startSection('sidebar'); ?>

    <?php echo $__env->yieldSection(); ?>

    <br><br>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>

</html><?php /**PATH D:\xampp\htdocs\fingent-interview\resources\views/layouts/app.blade.php ENDPATH**/ ?>